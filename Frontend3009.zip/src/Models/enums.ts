export enum Role {
    Admin = 1,
    User = 2
}
