export class LikeModel {
  public id: number;
  public userId: number;
  public vacationId: number;
}
