import "./Copyrights.css";

function Copyrights(): JSX.Element {
    return (
        <div className="Copyrights">
			<p>All Rights Reserved ©</p>
        </div>
    );
}

export default Copyrights;
